/*
 * Featured Image Popup Setting
 */

jQuery(document).ready(function () {
   jQuery('.image-popup').magnificPopup({type: 'image'});
});